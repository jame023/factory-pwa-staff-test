import * as workApi from "../../adapters/package07.js?v=1.3.267";
import { renderProductionWorkPanel } from "./production-work.js?v=1.3.369";
import { escapeHtml } from "../../js/utils.js?v=1.3.186";

export async function render(root, context) {
  root.innerHTML = '<div class="page-loading"><span class="loading-spinner"></span><span>กำลังโหลดข้อมูลการผลิต…</span></div>';
  try {
    const activeRows = await workApi.listActiveWorkSessions();
    if (context.signal?.aborted) return;
    const active = activeRows.find(item => item.employeeId === context.user.id && item.workType === "ผลิต" && !item.endedAt) || null;
    root.innerHTML =
      '<div class="page-heading"><div><p class="eyebrow">PASS 5.3</p><h1>ข้อมูลการผลิต</h1><p>บันทึกจำนวนผลิตและของเสีย แยกจากหน้าเริ่มงาน–จบงานผลิต</p></div></div>' +
      (active
        ? '<p class="notice notice-info">มีงานผลิตกำลังทำอยู่ที่ ' + escapeHtml(active.machine || "เครื่องจักร") + ' · บันทึกยอดของงานนี้ในหน้านี้ แล้วกลับไปจบงานที่หน้าเริ่มงาน–จบงานผลิต</p>'
        : '<p class="notice notice-info">แบบฟอร์มบันทึกยอดจะเปิดเมื่อเริ่มงานผลิตแล้ว หากยังไม่มีงาน ให้เริ่มจากเมนู “เริ่มงาน–จบงานผลิต”</p>') +
      '<div data-production-data-panel></div>';
    const panel = root.querySelector("[data-production-data-panel]");
    await renderProductionWorkPanel(panel, context, { active, onRefresh: () => render(root, context) });
  } catch (error) {
    if (context.signal?.aborted) return;
    root.innerHTML = '<div class="page-heading"><div><p class="eyebrow">PASS 5.3</p><h1>ข้อมูลการผลิต</h1></div></div>' +
      '<div class="notice notice-error" role="alert">โหลดข้อมูลการผลิตไม่สำเร็จ: ' + escapeHtml(error.message || "ไม่สามารถเชื่อมต่อได้") + '</div>' +
      '<button class="button button-primary" type="button" data-production-retry>ลองใหม่</button>';
    root.querySelector("[data-production-retry]")?.addEventListener("click", () => render(root, context));
  }
}
