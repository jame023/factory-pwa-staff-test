import * as workApi from '../../adapters/package07.js?v=1.3.372';
import { bangkokToday, escapeHtml as e, thaiDate } from '../../js/utils.js?v=1.3.186';
import { requireOnlineAction } from '../../js/offline.js?v=1.3.186';

export async function renderIndependentOutput(root, context, group) {
  root.innerHTML='<p class="page-loading">กำลังโหลดข้อมูล…</p>';
  let options, history;
  try { [options,history]=await Promise.all([workApi.readWorkOptions(group),workApi.readIndependentOutput(group)]); }
  catch(error) { if(!context.signal?.aborted) root.innerHTML='<p class="notice notice-error" role="alert">โหลดข้อมูลไม่สำเร็จ: '+e(error.message||'กรุณาลองใหม่')+'</p>'; return; }
  if(context.signal?.aborted)return;
  const screen=group==='สกรีน';
  const machines=options.machines||[], items=options.orders||[];
  const machineOptions=machines.map(x=>'<option value="'+e(x.id)+'">'+e([x.machine_code,x.machine_name].filter(Boolean).join(' · '))+'</option>').join('');
  const itemOptions=items.map(x=>'<option value="'+e(x.id)+'">'+e(x.item_name)+'</option>').join('');
  const rowMarkup=()=>'<div class="form-grid independent-item"><label class="field">รายการชื่อ<select name="itemName" required><option value="">เลือกรายการ</option>'+itemOptions+'</select></label><label class="field">จำนวนแพ็คดี<input name="packCount" type="number" min="1" max="1000000000" step="1" inputmode="numeric" required></label><label class="field">ช่วงงาน<select name="workPeriod"><option value="REGULAR">ในเวลา</option><option value="OT">OT</option></select></label><button class="button" type="button" data-remove-item>ลบรายการ</button></div>';
  const label=screen?'บันทึกงานสกรีน':'บันทึกข้อมูลผลิต';
  root.innerHTML='<section class="card form-card"><div class="section-title"><div><h2>'+label+'</h2><p>กรอกยอดงานแยกจากการเริ่มและจบงาน</p></div></div><form id="independent-output-form"><div class="form-grid">'+
    '<label class="field">วันที่<input name="date" type="date" required value="'+e(bangkokToday())+'"></label><label class="field">เครื่องจักร<select name="machineId" required '+(!machines.length?'disabled':'')+'><option value="">เลือกเครื่องจักร</option>'+machineOptions+'</select></label>'+
    (screen?'':'<label class="field">จำนวนผลิต (ใบ)<input name="quantity" type="number" min="1" max="1000000000" step="1" required></label><label class="field">ของเสีย (ใบ)<input name="defective" type="number" min="0" max="1000000000" step="1" value="0" required></label>')+'</div>'+
    (screen?'<div data-screen-items>'+rowMarkup()+'</div><div class="form-actions"><button class="button" type="button" data-add-item>เพิ่มรายการ</button><button class="button" type="button" data-no-packs>ไม่มีแพ็คดี</button></div><p class="help-text">เลือกช่วงงานและระบุจำนวนแพ็คดีในแต่ละรายการ</p><div class="form-grid"><label class="field">เสียจากสกรีน (ขวด)<input name="screenDefects" type="number" min="0" step="1" value="0" required></label><label class="field">เสียจากผลิต (ขวด)<input name="productionDefects" type="number" min="0" step="1" value="0" required></label></div>':'')+
    '<label class="field">หมายเหตุ<textarea name="note" maxlength="500"></textarea></label><p data-save-status class="help-text" role="status"></p><div class="form-actions"><button class="button button-primary" type="submit" '+(!machines.length?'disabled':'')+'>บันทึกข้อมูล</button></div></form></section>'+
    '<section class="card card-pad attendance-section"><h2>รายการที่บันทึกของฉัน</h2><div class="list">'+(history.slice(0,20).map(x=>'<article class="list-row"><div><strong>'+e(x.date?thaiDate(x.date):'—')+' · '+e(x.machine||x.sheetName||'—')+'</strong><p>'+ (screen?'แพ็คดี '+e(x.enteredPack??'—')+' · เสียสกรีน '+e(x.missingBottles??'—')+' · เสียผลิต '+e(x.productionDamagedBottles??'—'):'ผลิต '+e(x.quantity??'—')+' ใบ · เสีย '+e(x.defective??'—')+' ใบ')+'</p>'+(screen&&Array.isArray(x.items)&&x.items.length?'<details><summary>ดูรายการและจำนวนแพ็ค</summary>'+x.items.map(item=>'<p>'+e(item.item_name_snapshot)+' · '+e(item.pack_count)+' แพ็ค · '+e(item.work_period==='OT'?'OT':'ในเวลา')+'</p>').join('')+'</details>':'')+'</div></article>').join('')||'<p class="empty-state">ยังไม่มีรายการ</p>')+'</div></section>';
  const form=root.querySelector('#independent-output-form'), status=root.querySelector('[data-save-status]');
  const key='factory-independent-output:'+context.user.id+':'+group;
  const list=form.querySelector('[data-screen-items]');
  form.querySelector('[data-add-item]')?.addEventListener('click',()=>{delete form.dataset.zeroPacks;list.insertAdjacentHTML('beforeend',rowMarkup());});
  form.querySelector('[data-no-packs]')?.addEventListener('click',()=>{list.replaceChildren();form.dataset.zeroPacks='true';status.textContent='ไม่มีแพ็คดี สามารถบันทึกของเสียและหมายเหตุได้';});
  form.addEventListener('click',event=>{if(event.target.closest('[data-remove-item]'))event.target.closest('.independent-item')?.remove();});
  let pending;
  try { pending=JSON.parse(sessionStorage.getItem(key)||'null'); } catch { status.textContent='ไม่สามารถอ่านคำขอบันทึกเดิม กรุณาติดต่อ Admin'; form.querySelector('[type=submit]').disabled=true; return; }
  const freeze=()=>{form.querySelectorAll('input,select,textarea,button:not([type=submit])').forEach(x=>x.disabled=true);};
  if(pending){
    for(const name of ['date','machineId','quantity','defective','screenDefects','productionDefects','note']){
      const field=form.elements.namedItem(name); if(field&&pending[name]!=null)field.value=String(pending[name]);
    }
    if(screen){
      list.innerHTML=(pending.items||[]).map(()=>rowMarkup()).join('');
      [...list.querySelectorAll('.independent-item')].forEach((row,index)=>{
        const saved=pending.items[index]; row.querySelector('[name=itemName]').value=saved.item_name_id;
        row.querySelector('[name=packCount]').value=saved.pack_count; row.querySelector('[name=workPeriod]').value=saved.work_period;
      });
      if(!(pending.items||[]).length)form.dataset.zeroPacks='true';
    }
    freeze();status.textContent='พบรายการที่ยังไม่ทราบผล กดตรวจสอบรายการเดิมอีกครั้ง';form.querySelector('[type=submit]').textContent='ตรวจสอบรายการเดิม';
  }
  form.addEventListener('submit',async event=>{
    event.preventDefault();const button=form.querySelector('[type=submit]');
    if(button.disabled||!requireOnlineAction(label))return;
    if(!pending){
      const data=new FormData(form);
      const rows=screen?[...form.querySelectorAll('.independent-item')].map(row=>({item_name_id:row.querySelector('[name=itemName]').value,pack_count:Number(row.querySelector('[name=packCount]').value),work_period:row.querySelector('[name=workPeriod]').value})):null;
      if(screen&&(!rows.length&&form.dataset.zeroPacks!=='true'||rows.some(x=>!x.item_name_id||!Number.isSafeInteger(x.pack_count)||x.pack_count<1))){status.textContent='ตรวจรายการชื่อและจำนวนแพ็ค หรือกดไม่มีแพ็คดี';return;}
      const quantity=screen?null:Number(data.get('quantity')),defective=screen?null:Number(data.get('defective'));
      if(!screen&&(!Number.isSafeInteger(quantity)||quantity<1||!Number.isSafeInteger(defective)||defective<0||defective>quantity)){status.textContent='ตรวจจำนวนผลิตและของเสีย';return;}
      pending={requestId:crypto.randomUUID(),group,date:data.get('date'),machineId:data.get('machineId'),quantity,defective,items:rows,screenDefects:screen?Number(data.get('screenDefects')):null,productionDefects:screen?Number(data.get('productionDefects')):null,note:String(data.get('note')||'').trim()};
      try {sessionStorage.setItem(key,JSON.stringify(pending));} catch {pending=null;status.textContent='ไม่สามารถเก็บคำขอเพื่อตรวจสอบการบันทึกซ้ำ';return;}
      freeze();
    }
    button.disabled=true;status.textContent='กำลังบันทึกและตรวจสอบข้อมูล…';
    try {await workApi.saveIndependentOutput(pending);sessionStorage.removeItem(key);pending=null;if(!context.signal?.aborted){context.showToast('บันทึกข้อมูลสำเร็จ','success');await renderIndependentOutput(root,context,group);}}
    catch(error){if(!context.signal?.aborted){if(error.serverRejected){sessionStorage.removeItem(key);pending=null;form.querySelectorAll('input,select,textarea,button').forEach(x=>x.disabled=false);status.textContent=error.message||'ข้อมูลไม่ผ่านการตรวจสอบ กรุณาแก้ไข';button.textContent='บันทึกข้อมูล';}else{status.textContent=(error.message||'ยังตรวจสอบผลไม่ได้')+' กดตรวจสอบรายการเดิมอีกครั้ง';button.textContent='ตรวจสอบรายการเดิม';}}}
    finally {if(button.isConnected)button.disabled=false;}
  });
}
