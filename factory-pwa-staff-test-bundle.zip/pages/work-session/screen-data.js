import { renderIndependentOutput } from './independent-output.js?v=1.3.393';
export function render(root,context) { return renderIndependentOutput(root,context,'สกรีน'); }
