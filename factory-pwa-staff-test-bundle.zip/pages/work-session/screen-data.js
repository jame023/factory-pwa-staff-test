import { renderIndependentOutput } from './independent-output.js?v=1.3.382';
export function render(root,context) { return renderIndependentOutput(root,context,'สกรีน'); }
