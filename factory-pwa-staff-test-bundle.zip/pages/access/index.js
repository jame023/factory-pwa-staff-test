import { iconMarkup, routeIcon } from '../../js/ui-icons.js?v=1.3.218';
import { getAuthContext, canAccessRoute, selectActiveGroup, availableWorkspaces } from '../../js/access-context.js?v=1.3.228';
import { ROUTES, normalizeRoute, workspaceGroups, groupRoute } from '../../js/route-policy.js?v=1.3.228';
import { escapeHtml } from '../../js/utils.js?v=1.3.186';
import { showStatusModal } from '../../components/status-modal.js?v=1.3.186';
const adminMenuPresentation = Object.freeze({
  '/admin/employees': {tone:'blue',hint:'ข้อมูลพนักงานและสถานะการใช้งาน',icon:'<circle cx="9" cy="8" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3M16 5a3 3 0 0 1 0 6M21 21v-3a6 6 0 0 0-4-5.65"/>'},
  '/admin/groups': {tone:'violet',hint:'กลุ่มงานหลักและสิทธิ์ของพนักงาน',icon:'<rect x="9" y="3" width="6" height="6" rx="1.5"/><rect x="2" y="15" width="6" height="6" rx="1.5"/><rect x="16" y="15" width="6" height="6" rx="1.5"/><path d="M12 9v3M5 15v-3h14v3"/>'},
  '/admin/machines': {tone:'teal',hint:'ทะเบียนเครื่องจักรและสถานะพร้อมใช้งาน',icon:'<path d="M3 21V9l6 3V7l6 3V4h5v17H3Z"/><path d="M7 17h1M12 17h1M17 17h1"/>'},
  '/admin/items': {tone:'green',hint:'เพิ่มและดูแลชื่อสินค้าที่ใช้ในโรงงาน',icon:'<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="M3 8v9l9 5 9-5V8M12 13v9M7.5 5.5l9 5"/>'},
  '/admin/registration-requests': {tone:'amber',hint:'ตรวจข้อมูลผู้สมัครและกำหนดกลุ่มงาน',icon:'<rect x="4" y="4" width="16" height="18" rx="2"/><rect x="8" y="2" width="8" height="4" rx="1"/><path d="m8 13 2 2 5-5M8 18h8"/>'},
  '/admin/audit-logs': {tone:'slate',hint:'ประวัติการทำรายการและการเปลี่ยนแปลง',pending:true,icon:'<path d="M3 11a9 9 0 1 1 2.6 7M3 4v7h7"/><path d="M12 7v5l3 2"/>'}
});
function adminIcon(paths) {return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'+paths+'</svg>';}
function renderAdminHome(root,context,links) {
  const managing=normalizeRoute(location.hash)==='/admin/manage';
  const categoryItems=[
    {path:'/employee',label:'พนักงาน',tone:'blue',hint:'เข้าสู่เมนูและพื้นที่ทำงานของพนักงาน'},
    {path:'/executive',label:'ผู้บริหาร',tone:'teal',hint:'เข้าสู่เมนูและภาพรวมสำหรับผู้บริหาร'},
    {path:'/admin/manage',label:'Admin',tone:'violet',hint:'แก้ไขข้อมูลพนักงาน เครื่องจักร รายชื่อสินค้า คำขอลงทะเบียน และกลุ่มงาน'}
  ].filter(item=>canAccessRoute(item.path));
  const managementOrder=['/admin/employees','/admin/machines','/admin/items','/admin/registration-requests','/admin/groups','/admin/audit-logs'];
  const items=managing?managementOrder.map(path=>links.find(route=>route.path===path)).filter(Boolean).map(route=>({...route,...adminMenuPresentation[route.path]})):categoryItems;
  const title=managing?'เมนูจัดการของ Admin':'เลือกพื้นที่ใช้งาน';
  root.innerHTML='<section class="admin-hub" aria-labelledby="admin-hub-title"><header class="admin-hub-heading"><div><span class="admin-hub-kicker">ระบบโรงงาน SIP</span><h1 id="admin-hub-title">'+title+'</h1><p>สวัสดี, <strong>'+escapeHtml(context.employee_name||'ผู้ดูแลระบบ')+'</strong><span>'+ (managing?'เลือกข้อมูลที่ต้องการจัดการ':'เลือกหมวดเพื่อเปิดเมนูที่ต้องการใช้งาน')+'</span></p></div><span class="admin-hub-role">'+iconMarkup(routeIcon('/admin'))+'ผู้ดูแลระบบ</span></header>'+
   (managing?'<div class="form-actions"><a class="button" href="#/admin">กลับหน้าเลือกหมวด</a></div>':'')+
   '<div class="workspace-section-title"><h2>'+(managing?'ข้อมูลและการตั้งค่า':'หมวดการใช้งาน')+'</h2></div><nav class="admin-hub-grid" aria-label="'+(managing?'เมนูจัดการ Admin':'เลือกหมวดการใช้งาน')+'">'+items.map(item=>
    '<'+(item.pending?'div aria-disabled="true"':'a href="#'+item.path+'"')+' class="admin-hub-card admin-hub-card--'+item.tone+'"><span class="admin-hub-card-top"><span class="admin-hub-icon">'+(item.icon?adminIcon(item.icon):iconMarkup(routeIcon(item.path)))+'</span><span class="admin-hub-arrow" aria-hidden="true">'+iconMarkup('arrow')+'</span></span><span class="admin-hub-card-title">'+escapeHtml(item.label)+'</span><span class="admin-hub-card-hint">'+escapeHtml(item.hint)+'</span>'+(item.pending?'<span class="admin-hub-pending">ยังไม่เปิดใช้งาน</span>':'')+'</'+(item.pending?'div':'a')+'>'
   ).join('')+'</nav></section>';
}
const workspaceHints={
 '/employee/profile':'ข้อมูลส่วนตัวและบัญชีของฉัน', '/employee/attendance':'ตรวจสอบเวลาเข้า–ออกงานของฉัน',
 '/employee/leave':'คำขอลาและประวัติการลา', '/employee/calendar':'วันทำงาน วันหยุด และกิจกรรม',
 '/employee/ot':'งานล่วงเวลาและรายการของฉัน', '/employee/screen':'พื้นที่ทำงานของกลุ่มสกรีน',
 '/employee/screen/work-session':'เริ่มงานและจบงานของกลุ่มสกรีน', '/employee/production':'พื้นที่ทำงานของกลุ่มผลิต',
 '/employee/production/work-session':'เริ่มงานและจบงานของกลุ่มผลิต', '/employee/delivery':'พื้นที่ทำงานของกลุ่มขนส่ง',
 '/employee/office':'พื้นที่ทำงานของกลุ่มออฟฟิศ', '/employee/select-group':'เปลี่ยนพื้นที่จากกลุ่มงานที่ได้รับ',
 '/executive/attendance':'ภาพรวมเวลาทำงานของพนักงาน', '/executive/reports':'รายงานและภาพรวมการทำงาน',
 '/executive/ot':'ภาพรวมงานล่วงเวลา', '/employee':'เมนูการทำงานของฉัน','/employee/home':'กลับหน้าหลักพนักงาน',
 '/executive':'ภาพรวมและรายงานสำหรับผู้บริหาร', '/admin':'กลับพื้นที่ Admin'
};
const workspaceHomes=['/employee','/employee/home','/executive','/employee/office','/employee/screen','/employee/production','/employee/delivery','/employee/select-group'];
function workspaceLink(route){
 const enabled=workspaceHomes.includes(route.path);
 return '<'+(enabled?'a href="#'+route.path+'"':'div aria-disabled="true"')+' class="workspace-card"><span class="workspace-card-icon">'+iconMarkup(routeIcon(route.path))+'</span><span class="workspace-card-copy"><strong>'+escapeHtml(route.label)+'</strong><span>'+escapeHtml(route.hint||workspaceHints[route.path]||'เลือกเพื่อเปิดพื้นที่นี้')+'</span>'+(!enabled?'<span class="admin-hub-pending">ยังไม่เปิดใช้งาน</span>':'')+'</span>'+(enabled?'<span class="workspace-card-arrow">'+iconMarkup('arrow')+'</span>':'')+'</'+(enabled?'a':'div')+'>';
}
function renderWorkspace(root,context,path,entry,links){
 const home=workspaceHomes.includes(path);
 const label=['/employee/office','/employee/screen','/employee/production','/employee/delivery'].includes(path)?context.selected_group:entry?.label||'พื้นที่ทำงาน';
 const roleLabel=context.role==='executive'?'ผู้บริหาร':context.role==='admin'?'ผู้ดูแลระบบ':'พนักงาน';
 root.innerHTML='<section class="workspace-hub"><header class="workspace-heading"><span class="workspace-heading-icon">'+iconMarkup(routeIcon(path))+'</span><div><span class="workspace-kicker">'+escapeHtml(roleLabel)+(context.selected_group?' · '+escapeHtml(context.selected_group):'')+'</span><h1>'+escapeHtml(label)+'</h1><p>'+escapeHtml(home?'สวัสดี, '+(context.employee_name||'')+' เลือกเมนูที่ต้องการใช้งาน':workspaceHints[path]||'ข้อมูลและเมนูที่เกี่ยวข้อง')+'</p></div></header>'+
 '<div class="form-actions">'+((path.startsWith('/employee/')||path==='/executive'||path.startsWith('/executive/'))?'<a class="button" href="#/employee">ย้อนกลับไปเลือกพื้นที่</a>':'')+(canAccessRoute('/admin')?'<a class="button" href="#/admin">กลับหน้าเลือกหมวด</a>':'')+'</div>'+
 (!home?'<section class="workspace-pending" role="status"><span>'+iconMarkup('info')+'</span><div><strong>หน้านี้ยังไม่เปิดใช้งาน</strong><p>ยังไม่สามารถดูหรือบันทึกรายการในหน้านี้ได้ เลือกเมนูอื่นด้านล่างเพื่อใช้งานต่อ</p></div></section>':'')+
 (['/employee/delivery','/employee/screen','/employee/production'].includes(path)?'<div class="workspace-card" aria-disabled="true"><span class="workspace-card-copy"><strong>'+escapeHtml(entry.label)+'</strong><span>ยังไม่เปิดใช้งาน</span></span></div>':'')+
 '<div class="workspace-section-title"><h2>'+(home?'เมนูของฉัน':'เมนูที่เกี่ยวข้อง')+'</h2><span>แสดงตามสิทธิ์ปัจจุบัน</span></div><nav class="workspace-menu" aria-label="เมนูตามสิทธิ์">'+links.filter(r=>r.path!==path&&r.path!=='/employee/select-group').map(workspaceLink).join('')+'</nav></section>';
}
export async function render(root) {
  const context=getAuthContext(),path=normalizeRoute(location.hash),entry=ROUTES[path];
  root.innerHTML='<section class="card card-pad"><h1>'+escapeHtml(entry?.label||'ไม่มีสิทธิ์เข้าหน้านี้')+'</h1><div data-access-content></div></section>';
  const content=root.querySelector('[data-access-content]');
  if(['/unauthorized','/account-blocked','/not-found'].includes(path)) {
    root.innerHTML='<section class="ui-access-state card"><span class="ui-state-icon">'+iconMarkup('lock')+'</span><span class="eyebrow">การเข้าถึงบัญชี</span><h1>'+escapeHtml(entry.label)+'</h1><p>'+escapeHtml(path==='/not-found'?'ตรวจสอบลิงก์ หรือกลับไปเลือกพื้นที่ทำงาน':path==='/account-blocked'?'กรุณาติดต่อ Admin เพื่อตรวจสอบสถานะบัญชีของคุณ':'บัญชีของคุณยังไม่มีสิทธิ์สำหรับหน้านี้ กรุณากลับไปเลือกเมนูที่ใช้งานได้')+'</p><a class="button button-primary" href="#/home">กลับหน้าหลัก</a><a class="button" href="#/employee/select-group">เลือกพื้นที่ทำงาน</a></section>';return;
  }
  if(['/employee','/employee/select-group'].includes(path)) {
    root.querySelector('section').classList.add('workspace-selector');
    if(path==='/employee')root.querySelector('h1').textContent='เลือกพื้นที่ทำงาน';
    const areas=availableWorkspaces(context).filter(area=>path!=='/employee'||area.id!=='Admin');
    content.innerHTML='<p class="workspace-select-hint">'+(path==='/employee'?'เลือกกลุ่มงานเพื่อดูเมนูและรายละเอียดพื้นที่ ระบบจะแสดงเฉพาะพื้นที่ที่บัญชีนี้ได้รับอนุญาต':'เลือกพื้นที่ทำงาน ระบบจะตรวจสิทธิ์ล่าสุดก่อนเปิดพื้นที่')+'</p><div class="workspace-menu">'+areas.map(area=>'<button type="button" class="workspace-card" data-group="'+escapeHtml(area.id)+'" aria-pressed="'+String(context.selected_workspace===area.id)+'"><span class="workspace-card-icon">'+iconMarkup(routeIcon(area.path))+'</span><span class="workspace-card-copy"><strong>'+escapeHtml(area.label)+'</strong><span>'+(context.selected_workspace===area.id?'กำลังใช้งาน':escapeHtml(workspaceHints[area.path]||'เข้าสู่พื้นที่ '+area.label))+'</span></span></button>').join('')+'</div>'+(!areas.length?'<p role="status">ไม่มีพื้นที่ที่เข้าใช้งานได้ กรุณาติดต่อ Admin หรือออกจากระบบ</p>':'')+'<p class="workspace-selection-error" role="alert"></p>';
    let busy=false;
    for(const button of content.querySelectorAll('[data-group]'))button.addEventListener('click',async()=>{
      if(busy)return;busy=true;
      content.querySelectorAll('button').forEach(item=>item.disabled=true);
      const modal=showStatusModal({message:'กำลังตรวจสอบสิทธิ์และเปลี่ยนพื้นที่',tone:'working'});
      try {const selected=await selectActiveGroup(button.dataset.group);modal.close();location.hash='#'+selected.workspace_path;}
      catch(error){modal.close();if(content.isConnected)content.querySelector('[role="alert"]').textContent=error.message;}
      finally{busy=false;content.querySelectorAll('button').forEach(item=>item.disabled=false);}
    });return;
  }
  const workspace=path.startsWith('/admin')?'/admin':path.startsWith('/executive')?'/executive':'/employee';
  const links=Object.values(ROUTES).filter(r=>r.path.startsWith(workspace)&&canAccessRoute(r.path)&&
    (!workspaceGroups(context).includes(r.rule)||!context.selected_group||r.rule===context.selected_group));
  if(path==='/admin'||path==='/admin/manage'){renderAdminHome(root,context,links);return;}
  const selected=context.selected_group;
  const filtered=links.filter(route=>{
    if(['/employee','/employee/home'].includes(route.path))return false;
    if(route.path==='/employee/ot')return selected!=='ออฟฟิศ';
    if(['สกรีน','ผลิต','ขนส่ง','ออฟฟิศ'].includes(route.rule))return route.rule===selected;
    return true;
  });
  renderWorkspace(root,context,path,entry,filtered);
}

