import { renderOvertimeReport } from "./index.js?v=1.3.352";
export const render = renderOvertimeReport;

