export async function render(root) {
  root.innerHTML = '<section class="notice notice-warning"><h1>ปิดหมวดอุปกรณ์แล้ว</h1></section>';
}
