import {
  disableDeviceNotifications,
  enableDeviceNotifications,
  markNotificationRead,
  readDeviceNotificationState,
  readNotificationInbox
} from '../../js/notification-client.js?v=1.3.355';
import { escapeHtml as e } from '../../js/utils.js?v=1.3.186';

const number = value => Number(value || 0).toLocaleString('th-TH');
const duration = value => {
  const minutes = Number(value || 0);
  return String(Math.floor(minutes / 60)).padStart(2, '0') + ':' + String(minutes % 60).padStart(2, '0');
};
const metric = (label, value, unit = '') => '<div class="notification-report-metric"><span>' + e(label) + '</span><strong>' + e(number(value)) + (unit ? ' ' + e(unit) : '') + '</strong></div>';

function snapshotMarkup(report) {
  const categories = report?.categories;
  if (!categories || typeof categories !== 'object') return '';
  const cards = [
    ['เวลาเข้า–ออก', categories.attendance, [['รายการ', 'records'], ['มาทำงาน', 'present'], ['มาสาย', 'late'], ['ขาดงาน', 'absent']]],
    ['การลา', categories.leave, [['คำขอ', 'requests'], ['อนุมัติ', 'approved'], ['รอตรวจ', 'pending'], ['ปฏิเสธ', 'rejected']]],
    ['ปฏิทินงาน', categories.calendar, [['วัน', 'entries'], ['กำหนดทำงาน', 'workdays'], ['วันหยุด', 'holidays']]],
    ['เริ่มงาน–จบงาน', categories.workSessions, [['งาน', 'total'], ['จบแล้ว', 'completed'], ['กำลังทำ', 'inProgress']]],
    ['งานสกรีน', categories.screen, [['รายการ', 'entries'], ['แพ็คดี', 'goodPacks'], ['เสียจากสกรีน', 'screenDefects'], ['เสียจากผลิต', 'productionDefects']]],
    ['งานผลิต', categories.production, [['รายการ', 'entries'], ['จำนวนผลิต', 'quantity'], ['ของเสีย', 'defective']]],
    ['การขนส่ง', categories.delivery, [['รายการ', 'entries'], ['จำนวนสินค้า', 'quantity']]],
    ['OT', categories.overtime, [['รายงาน', 'reports'], ['พนักงาน', 'employees'], ['เวลารวม', 'minutes', 'duration']]]
  ];
  return '<section class="notification-report"><h3>สรุปรวมทุกหมวด</h3><div class="notification-report-grid">' + cards.map(([title, data, fields]) => {
    if (!data) return '';
    return '<article class="notification-report-card"><h4>' + e(title) + '</h4><div>' + fields.map(([label, key, kind]) =>
      '<p><span>' + e(label) + '</span><strong>' + e(kind === 'duration' ? duration(data[key]) : number(data[key])) + (kind === 'duration' ? '' : '') + '</strong></p>'
    ).join('') + '</div></article>';
  }).join('') + '</div><p class="small-muted">ช่วง ' + e(report.source?.from || '') + ' – ' + e(report.source?.to || '') + ' · ข้อมูล ณ ' + e(report.source?.asOf ? new Intl.DateTimeFormat('th-TH', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(report.source.asOf)) : '—') + '</p></section>';
}

function eventDetails(row) {
  const data = row.data && typeof row.data === 'object' ? row.data : {};
  if (data.report) return snapshotMarkup(data.report);
  const facts = [];
  if (data.employee_name) facts.push(['พนักงาน', data.employee_name]);
  if (data.start_date || data.end_date) facts.push(['วันที่ลา', [data.start_date, data.end_date].filter(Boolean).join(' – ')]);
  if (data.period) facts.push(['ช่วงเวลา', data.period]);
  if (data.group) facts.push(['กลุ่มงาน', data.group]);
  if (data.date) facts.push(['วันที่', data.date]);
  if (data.status) facts.push(['สถานะ', data.status]);
  if (Array.isArray(data.entries) && data.entries.length) facts.push(['วันที่และสถานะที่บันทึก', data.entries.map(item => [item.date, item.status].filter(Boolean).join(' • ')).join(' / ')]);
  return facts.length ? '<dl class="notification-event-facts">' + facts.map(([label, value]) => '<div><dt>' + e(label) + '</dt><dd>' + e(value) + '</dd></div>').join('') + '</dl>' : '';
}

function dateLabel(value) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return '—';
  return new Intl.DateTimeFormat('th-TH', { dateStyle: 'medium', timeStyle: 'short' }).format(date);
}

function safeRoute(route) {
  const allowed = new Set([
    '#/notifications',
    '#/employee/leave',
    '#/executive/leave',
    '#/employee/reports',
    '#/executive/registration-requests',
    '#/admin/registration-requests'
  ]);
  return allowed.has(route) ? route : '#/notifications';
}

export async function render(root, context) {
  let generation = 0;
  let busy = false;
  const draw = async () => {
    const current = ++generation;
    root.innerHTML = '<p class="page-loading">กำลังโหลดการแจ้งเตือน…</p>';
    try {
      const [rows, device] = await Promise.all([readNotificationInbox(100), readDeviceNotificationState()]);
      if (current !== generation || context.signal?.aborted) return;
      const pushText = !device.supported
        ? 'อุปกรณ์หรือเบราว์เซอร์นี้ยังไม่รองรับการแจ้งเตือนเมื่อปิดแอป'
        : device.enabled ? 'อุปกรณ์นี้เปิดรับการแจ้งเตือนแล้ว' :
          device.permission === 'denied' ? 'การแจ้งเตือนถูกปิดในตั้งค่าเบราว์เซอร์' :
            'เปิดรับการแจ้งเตือนบนอุปกรณ์นี้ แม้ปิดแอปอยู่';
      const items = rows.length ? rows.map(row => {
        const route = safeRoute(row.route);
        return '<article class="notification-inbox-item' + (row.read_at ? '' : ' is-unread') + '" data-notification-id="' + e(row.id) + '">' +
          '<div class="notification-inbox-item-heading"><div><h2>' + e(row.title) + '</h2><time datetime="' + e(row.created_at) + '">' + e(dateLabel(row.created_at)) + '</time></div>' +
          (!row.read_at ? '<span class="notification-unread-badge">ใหม่</span>' : '') + '</div>' +
          '<p class="notification-inbox-body">' + e(row.body) + '</p>' + eventDetails(row) +
          '<div class="form-actions"><a class="button button-small" href="' + e(route) + '">เปิดข้อมูล</a>' +
          (!row.read_at ? '<button class="button button-small" type="button" data-mark-read>รับทราบ</button>' : '') + '</div></article>';
      }).join('') : '<div class="card card-pad notification-empty"><h2>ยังไม่มีการแจ้งเตือน</h2><p>เมื่อมีรายงานหรือรายการที่เกี่ยวข้อง ระบบจะแสดงไว้ที่นี่</p></div>';
      root.innerHTML = '<div class="page-heading"><div><p class="eyebrow">กล่องข้อความของคุณ</p><h1>แจ้งเตือนระบบงาน</h1><p>รายงานสรุป คำขอลา ปฏิทินงาน และคำขอสมัครที่เกี่ยวข้อง</p></div><button class="button" type="button" data-refresh>รีเฟรช</button></div>' +
        '<section class="card card-pad notification-push-card"><div><h2>แจ้งเตือนบนอุปกรณ์</h2><p>' + e(pushText) + '</p></div>' +
        (device.supported ? '<button class="button ' + (device.enabled ? '' : 'button-primary') + '" type="button" data-push-toggle>' + (device.enabled ? 'ปิดการแจ้งเตือนอุปกรณ์นี้' : 'เปิดการแจ้งเตือนอุปกรณ์นี้') + '</button>' : '') +
        '</section><section class="notification-inbox-list" aria-label="รายการแจ้งเตือน">' + items + '</section>';
      root.querySelector('[data-refresh]')?.addEventListener('click', () => void draw());
      root.querySelectorAll('[data-mark-read]').forEach(button => button.addEventListener('click', async event => {
        if (busy) return;
        busy = true;
        const article = event.currentTarget.closest('[data-notification-id]');
        event.currentTarget.disabled = true;
        try { await markNotificationRead(article.dataset.notificationId); await draw(); }
        catch (error) { context.showToast(error.message || 'บันทึกการรับทราบไม่สำเร็จ', 'error'); }
        finally { busy = false; }
      }));
      root.querySelector('[data-push-toggle]')?.addEventListener('click', async event => {
        if (busy) return;
        busy = true;
        const button = event.currentTarget;
        button.disabled = true;
        try {
          const result = device.enabled ? await disableDeviceNotifications() : await enableDeviceNotifications();
          context.showToast(result.status === 'permission_not_granted' ? 'ยังไม่ได้อนุญาตการแจ้งเตือนบนอุปกรณ์' : 'อัปเดตการแจ้งเตือนของอุปกรณ์แล้ว', result.status === 'permission_not_granted' ? 'info' : 'success');
          await draw();
        } catch (error) {
          context.showToast(error.message || 'ตั้งค่าการแจ้งเตือนไม่สำเร็จ', 'error');
          button.disabled = false;
        } finally { busy = false; }
      });
    } catch (error) {
      if (current !== generation || context.signal?.aborted) return;
      root.innerHTML = '<div class="notice notice-danger"><h1>โหลดการแจ้งเตือนไม่สำเร็จ</h1><p>' + e(error.message || 'กรุณาลองใหม่') + '</p><button class="button" type="button" data-retry>ลองใหม่</button></div>';
      root.querySelector('[data-retry]')?.addEventListener('click', () => void draw());
    }
  };
  context.onDataChange?.(() => void draw());
  await draw();
}
