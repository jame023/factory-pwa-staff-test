import { appCard } from "../../components/app-card.js?v=1.3.186";

const reports = [
  { route:"executive/reports", icon:"📊", title:"รายงานสรุป", hint:"ดูภาพรวมรายวัน รายสัปดาห์ และพนักงานดีเด่น" },
  { route:"executive/ot", icon:"⏱️", title:"รายงาน OT", hint:"ตรวจรายการ OT รายละเอียดงาน และรูปหลักฐาน" }
];

export async function render(root) {
  root.innerHTML =
    '<div class="page-heading"><div><p class="eyebrow">ระบบโรงงาน SIP</p><h1>เมนูรายงาน</h1>' +
    '<p>เลือกรายงานที่ต้องการดู</p></div></div>' +
    '<div class="module-grid">' + reports.map(appCard).join("") + '</div>';
}
