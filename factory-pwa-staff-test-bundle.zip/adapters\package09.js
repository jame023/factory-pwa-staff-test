import { request } from "../js/api.js?v=1.3.298";
export const listLeaveRequests = (scope = 'self') => request("package09", "leave.read", {scope});
export const readLeaveHistoryPage = filters => request("package09", "leave.history", filters);
export const readAdminLeaveHistoryPage = filters => request("package09", "leave.admin.history", filters || {});
export const readApprovedLeaveCalendar = month => request("package09", "leave.calendar", {month});
export const submitLeaveRequest = payload => request("package09", "leave.submit", payload);
export const submitProxyLeaveRequest = payload => request("package09", "leave.proxy.submit", payload);
export const reviewLeaveRequest = (id, decision, rejectionReason = "", updatedAt) =>
  request("package09", "leave.review", { id, decision, rejectionReason, updatedAt });

export const readLeaveNotifications = () => request("package09", "leave.notifications.read");
export const cancelLeaveRequest = (id, reason, updatedAt) => request("package09", "leave.cancel", { id, reason, updatedAt });
export const readLeaveOptions = () => request('package09','leave.options');
export const readLeaveDetail = id => request('package09','leave.detail',{id});
export const readLeaveImages = id => request('package09','leave.images',{id});
export const recoverLeaveOperations = () => request('package09','leave.recover');
export const mutateLeaveRequest = (operation,payload) => request('package09','leave.mutate',{...payload,operation});

export const readLeaveNoticeHistory = () => request("package09","leave.notices.read");
