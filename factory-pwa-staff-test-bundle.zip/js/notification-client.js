import { SUPABASE_PUBLISHABLE_KEY, SUPABASE_URL } from './config.js?v=1.3.355';
import { getSupabaseLineAccessToken } from './auth.js?v=1.3.205';
import { decodeVapidKey } from './report-push-subscription.js?v=1.3.354';

const FUNCTION_URL = SUPABASE_URL.replace(/\/+$/, '') + '/functions/v1/factory-notifications';

async function request(path, init = {}) {
  const token = getSupabaseLineAccessToken();
  if (!token) throw new Error('SESSION_EXPIRED');
  const response = await fetch(SUPABASE_URL.replace(/\/+$/, '') + path, {
    ...init,
    cache: 'no-store',
    redirect: 'error',
    headers: {
      apikey: SUPABASE_PUBLISHABLE_KEY,
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
      ...(init.body ? { 'Content-Type': 'application/json' } : {}),
      ...(init.headers || {})
    }
  });
  const raw = await response.text();
  let data = null;
  try { data = raw ? JSON.parse(raw) : null; } catch {}
  if (!response.ok) {
    if (response.status === 401) throw new Error('SESSION_EXPIRED');
    if (response.status === 403) throw new Error('ไม่มีสิทธิ์ใช้การแจ้งเตือน');
    if (response.status === 404) throw new Error('ยังไม่ได้ติดตั้งระบบแจ้งเตือนบน Supabase');
    throw new Error('เชื่อมต่อระบบแจ้งเตือนไม่สำเร็จ');
  }
  return data;
}

export async function readNotificationInbox(limit = 100) {
  const params = new URLSearchParams({
    select: 'id,kind,title,body,route,data,created_at,read_at',
    order: 'created_at.desc,id.desc',
    limit: String(Math.max(1, Math.min(100, Number(limit) || 100)))
  });
  const data = await request('/rest/v1/factory_notification_inbox?' + params);
  if (!Array.isArray(data)) throw new Error('รูปแบบรายการแจ้งเตือนไม่ถูกต้อง');
  return data;
}

export async function markNotificationRead(id) {
  if (typeof id !== 'string' || !/^[0-9a-f-]{36}$/i.test(id)) throw new Error('NOTIFICATION_ID_INVALID');
  const params = new URLSearchParams({ id: 'eq.' + id, select: 'id,read_at' });
  const rows = await request('/rest/v1/factory_notification_inbox?' + params, {
    method: 'PATCH',
    headers: { Prefer: 'return=representation' },
    body: JSON.stringify({ read_at: new Date().toISOString() })
  });
  if (!Array.isArray(rows) || rows.length !== 1) throw new Error('ไม่พบรายการแจ้งเตือน');
  return rows[0];
}

export async function summarizeCalendarChanges(recordIds) {
  if (!Array.isArray(recordIds) || recordIds.length < 1 || recordIds.length > 366 || recordIds.some(id => typeof id !== 'string' || !/^[0-9a-f-]{36}$/i.test(id))) {
    throw new Error('ข้อมูลปฏิทินสำหรับสรุปไม่ถูกต้อง');
  }
  return await rpc('factory_notification_calendar_summary', { p_record_ids: recordIds });
}

async function rpc(name, body) {
  return request('/rest/v1/rpc/' + name, { method: 'POST', body: JSON.stringify(body) });
}

function subscriptionBody(subscription) {
  const json = subscription?.toJSON?.();
  if (!json?.endpoint || !json?.keys?.p256dh || !json?.keys?.auth) throw new Error('PUSH_SUBSCRIPTION_INVALID');
  return json;
}

export async function enableDeviceNotifications() {
  if (!('serviceWorker' in navigator) || !('PushManager' in globalThis) || !('Notification' in globalThis)) {
    throw new Error('อุปกรณ์หรือเบราว์เซอร์นี้ยังไม่รองรับการแจ้งเตือนเมื่อปิดแอป');
  }
  const permission = await Notification.requestPermission();
  if (permission !== 'granted') return { status: 'permission_not_granted' };
  const registration = await navigator.serviceWorker.ready;
  const publicKeyResponse = await fetch(FUNCTION_URL + '?action=vapid-public-key', {
    method: 'GET',
    cache: 'no-store',
    headers: { apikey: SUPABASE_PUBLISHABLE_KEY },
    redirect: 'error'
  });
  if (!publicKeyResponse.ok) throw new Error('ไม่สามารถเตรียมการแจ้งเตือนบนอุปกรณ์ได้');
  const { publicKey } = await publicKeyResponse.json();
  const applicationServerKey = decodeVapidKey(publicKey);
  let subscription = await registration.pushManager.getSubscription();
  let created = false;
  if (!subscription) {
    subscription = await registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey });
    created = true;
  }
  try {
    const json = subscriptionBody(subscription);
    await rpc('factory_notification_push_save', {
      p_endpoint: json.endpoint,
      p_p256dh: json.keys.p256dh,
      p_auth_key: json.keys.auth
    });
  } catch (error) {
    if (created) await subscription.unsubscribe().catch(() => {});
    throw error;
  }
  return { status: 'enabled' };
}

export async function disableDeviceNotifications() {
  if (!('serviceWorker' in navigator)) throw new Error('อุปกรณ์นี้ยังไม่รองรับการแจ้งเตือน');
  const registration = await navigator.serviceWorker.ready;
  const subscription = await registration.pushManager?.getSubscription();
  if (!subscription) return { status: 'already_disabled' };
  await rpc('factory_notification_push_remove', { p_endpoint: subscription.endpoint });
  if (!await subscription.unsubscribe()) throw new Error('ปิดการแจ้งเตือนบนอุปกรณ์ไม่สำเร็จ');
  return { status: 'disabled' };
}

export async function readDeviceNotificationState() {
  if (!('serviceWorker' in navigator) || !('PushManager' in globalThis) || !('Notification' in globalThis)) {
    return { supported: false, enabled: false, permission: 'unsupported' };
  }
  const registration = await navigator.serviceWorker.ready;
  const subscription = await registration.pushManager.getSubscription();
  return { supported: true, enabled: Boolean(subscription), permission: Notification.permission };
}
