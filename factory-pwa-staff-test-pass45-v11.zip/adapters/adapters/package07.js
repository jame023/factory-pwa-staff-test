import { request } from "../js/api.js?v=1.3.254";
export const listWorkSessions = (options = {}) => request("package07", "work.read", {}, options);
export const startWorkSession = payload => request("package07", "work.start", payload);
export const endWorkSession = (id, quantity) => request("package07", "work.end", { id, quantity });

export const readWorkOptions = () => request("package07","work.options");
export const listOvertimeRequests = options => request("package07", "ot.read", options || {});
export const readOvertimeReport = id => request("package07", "ot.detail", { id });
export const recoverOvertimeAttempt = ownerId => request("package07", "ot.recover", { owner_id: ownerId });
export const recoverOvertimeEdit = ownerId => request("package07", "ot.edit.recover", { owner_id: ownerId });
export const editOvertimeReport = payload => request("package07", "ot.edit", payload);
export const submitOvertimeRequest = payload => request("package07", "ot.submit", payload);
